
public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
		Police p = new Police("hady");
		Chef c = new Chef("tintin");
		
		p.routine();
		c.routine();
	}

	public static void main(String[] args) {
		new Main();
	}
}
